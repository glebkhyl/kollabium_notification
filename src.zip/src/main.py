import json

from faststream import FastStream

from core.nats_client import broker, stream
from core.router import dispatch


@broker.subscriber("logs.events", stream=stream, queue="log-workers")
async def handle_log(event):
    # FastStream вернёт str или dict в зависимости от того, как публикуют
    if isinstance(event, str):
        try:
            event = json.loads(event)
        except json.JSONDecodeError:
            # если пришёл «сырой» текстовый лог – посылаем как есть
            event = {"kind": "RAW", "ctx": {"text": event}}

    await dispatch(event)


fs = FastStream(broker)
app = fs
