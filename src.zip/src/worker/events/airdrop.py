# worker/events/airdrop.py
from core.template_loader import render
from sinks import REGISTRY
from worker.events.registry import register
from worker.schemas.airdrop import (
    ClickInviteeCtx,
    ClickInviterCtx,
    CondReadyCtx,
    NewInviterCtx,
    NewRegCtx,
    PlanChangedCtx,
    RewardCtx,
)


@register("airdrop", "CLICK_INVITER")
async def _(ctx: dict):
    data = ClickInviterCtx.model_validate(ctx)
    text = render("CLICK_INVITER", data.model_dump())
    await REGISTRY["logs.telegram"].send({"text": text})


# …и аналогично для остальных событий@register("airdrop", "NEW_REG")
async def new_reg(ctx: dict):
    data = NewRegCtx.model_validate(ctx)
    text = render("NEW_REG", data.model_dump())
    await REGISTRY["logs.telegram"].send({"text": text})


@register("airdrop", "COND_READY")
async def cond_ready(ctx: dict):
    data = CondReadyCtx.model_validate(ctx)
    text = render("COND_READY", data.model_dump())
    await REGISTRY["logs.telegram"].send({"text": text})


@register("airdrop", "REWARD")
async def reward(ctx: dict):
    data = RewardCtx.model_validate(ctx)
    text = render("REWARD", data.model_dump())
    await REGISTRY["logs.telegram"].send({"text": text})
