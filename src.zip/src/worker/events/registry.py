from collections.abc import Awaitable, Callable
from typing import Any

_Handler = Callable[[dict[str, Any]], Awaitable[None]]
_HANDLERS: dict[str, dict[str, _Handler]] = {}  # channel → {kind: fn}


def register(channel: str, kind: str):

    def deco(fn: _Handler):
        _HANDLERS.setdefault(channel, {})[kind] = fn
        return fn

    return deco


async def dispatch(channel: str, kind: str, ctx: dict):
    try:
        await _HANDLERS[channel][kind](ctx)
    except KeyError:

        import logging

        logging.warning("no handler for %s:%s", channel, kind)
