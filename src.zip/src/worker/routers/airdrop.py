from faststream import Router
from faststream.nats import JStream
from schemas import ClickInviterCtx

from core.template_loader import render
from sinks import REGISTRY

stream = JStream(name="logs", subjects=["logs.events"])
airdrop_router = Router()


@airdrop_router.subscriber(
    "logs.events",
    stream=stream,
    queue="airdrop-workers",
    filter=lambda m: m.get("channel") == "airdrop",  # ← роутер получает
)  #    только airdrop
async def click_inviter(event: dict):
    if event["kind"] != "CLICK_INVITER":
        return

    ctx = ClickInviterCtx.model_validate(event["ctx"])
    text = render("CLICK_INVITER", ctx.model_dump())

    await REGISTRY["logs.telegram"].send({"text": text})
