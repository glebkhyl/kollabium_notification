# core/router.py
from worker.events.registry import REGISTRY


async def dispatch(event: dict):
    channel = event.get("channel")
    kind = event.get("kind")
    ctx = event.get("ctx", {})

    handler = REGISTRY.get((channel, kind))
    if not handler:
        print(f"⚠️  no handler for {(channel, kind)}")
        return

    await handler(ctx)
