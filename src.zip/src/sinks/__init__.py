from sinks import email, site, telegram
from sinks.base import REGISTRY

__all__ = ["REGISTRY"]
